/*
 * File Name : detailBooking.java
 * Date modified : 6/4/2020
 */

/**
 * @author Nasuha dan Hafizhan
 */
public class detailBooking extends customer{
    private int bookingId;
    private String bookingStatus;
    
    public detailBooking(String name, String address, int number, int bookingId, String bookingStatus) {
        super(name, address, number);
        setBookingId(bookingId);
        setBookingStatus(bookingStatus);
    }

    @Override
    public void bookingCheck() {
      System.out.println("Within bookingCheck of detailBooking class ");
      System.out.println("Check Booking for " + getName()
      + " with Booking Id: B" + bookingId);
      System.out.println("Booking status is " + getBookingStatus());
   }
   
   public double getBookingId() {
      return bookingId;
   }
   
   public void setBookingId(int newBookingId) {
      if(newBookingId > 0) {
         bookingId = newBookingId;
      }
   }
   
   public void setBookingStatus(String newbookingStatus) {
      bookingStatus = newbookingStatus;
   }
   
   public String getBookingStatus() {
      return bookingStatus;
   }
}
