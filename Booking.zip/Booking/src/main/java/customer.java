/*
 * File Name : customer.java
 * Date modified : 6/4/2020
 */

/**
 * @author Nasuha dan Hafizhan
 */
public class customer {
   private String name;
   private String address;
   private int number;

   public customer(String name, String address, int number) {
      System.out.println("Constructing a Booking...");
      this.name = name;
      this.address = address;
      this.number = number;
   }

   public void bookingCheck() {
      System.out.println("Check Booking for " + this.name + " " + this.address);
   }

   public String toString() {
      return name + " " + address + " " + number;
   }

   public String getName() {
      return name;
   }

   public String getAddress() {
      return address;
   }

   public void setAddress(String newAddress) {
      address = newAddress;
   }

   public int getNumber() {
      return number;
   }
}
