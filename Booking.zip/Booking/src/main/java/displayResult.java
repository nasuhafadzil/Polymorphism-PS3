/*
 * File Name : displayResult.java
 * Date modified : 6/4/2020
 */

/**
 * @author Nasuha dan Hafizhan
 */
public class displayResult {
    public static void main(String [] args) {
      detailBooking s = new detailBooking("Mohd NurHakim", "Ampang, Malaysia", 3, 132, "Accepted");
      customer e = new detailBooking("John Adams", "Skudai, Johor", 2, 133,"Rejected");
      System.out.println("\n\nCheck booking using detailBooking reference --");
      s.bookingCheck();
      System.out.println("\nCheck booking  using Customer reference--");
      e.bookingCheck();
   }
}
